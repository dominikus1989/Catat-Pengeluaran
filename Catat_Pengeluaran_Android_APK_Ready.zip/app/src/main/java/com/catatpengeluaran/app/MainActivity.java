package com.catatpengeluaran.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final int REQ_IMAGE = 1001;
    private static final String PREFS = "catat_keuangan_prefs";
    private static final String KEY_TX = "transactions";
    private static final String KEY_OPENING = "opening_balance";

    private final int GREEN = Color.rgb(20, 90, 50);
    private final int GREEN_2 = Color.rgb(30, 132, 73);
    private final int RED = Color.rgb(192, 57, 43);
    private final int ORANGE = Color.rgb(211, 84, 0);
    private final int BG = Color.rgb(245, 247, 249);
    private final int TEXT = Color.rgb(40, 45, 50);
    private final int MUTED = Color.rgb(110, 118, 125);

    private SharedPreferences prefs;
    private FrameLayout content;
    private LinearLayout nav;
    private int selectedTab = 0;

    private final String[] categories = {
            "Makan & Minum", "Belanja", "Transportasi", "Tagihan",
            "Cicilan", "Rumah", "Keluarga", "Hiburan",
            "Tabungan / Investasi", "Kesehatan", "Pemasukan", "Lain-lain"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(GREEN);
        getWindow().setNavigationBarColor(Color.WHITE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        nav = buildBottomNav();
        root.addView(nav, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(68)));

        setContentView(root);
        showTab(0);

        Intent intent = getIntent();
        if (Intent.ACTION_SEND.equals(intent.getAction())
                && intent.getType() != null
                && intent.getType().startsWith("image/")) {
            Uri imageUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (imageUri != null) {
                readScreenshot(imageUri);
            }
        }
    }

    private LinearLayout buildBottomNav() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(dp(4), dp(4), dp(4), dp(6));
        bar.setBackgroundColor(Color.WHITE);

        String[] labels = {"Home", "Transaksi", "Tambah", "Analisa", "Setting"};
        String[] icons = {"⌂", "☷", "+", "▥", "⚙"};

        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(2), dp(2), dp(2), dp(2));

            TextView icon = new TextView(this);
            icon.setText(icons[i]);
            icon.setTextSize(i == 2 ? 28 : 21);
            icon.setGravity(Gravity.CENTER);

            TextView label = new TextView(this);
            label.setText(labels[i]);
            label.setTextSize(11);
            label.setGravity(Gravity.CENTER);

            item.addView(icon, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(32)));
            item.addView(label, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

            item.setOnClickListener(v -> showTab(index));
            item.setTag(new TextView[]{icon, label});
            bar.addView(item, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.MATCH_PARENT, 1));
        }
        return bar;
    }

    private void updateNav() {
        for (int i = 0; i < nav.getChildCount(); i++) {
            LinearLayout item = (LinearLayout) nav.getChildAt(i);
            TextView[] parts = (TextView[]) item.getTag();
            int color = i == selectedTab ? GREEN_2 : MUTED;
            parts[0].setTextColor(color);
            parts[1].setTextColor(color);
            parts[1].setTypeface(null, i == selectedTab ? Typeface.BOLD : Typeface.NORMAL);
        }
    }

    private void showTab(int tab) {
        selectedTab = tab;
        updateNav();
        content.removeAllViews();
        if (tab == 0) content.addView(buildHome());
        else if (tab == 1) content.addView(buildHistory());
        else if (tab == 2) content.addView(buildAddMenu());
        else if (tab == 3) content.addView(buildAnalysis());
        else content.addView(buildSettings());
    }

    private View buildHome() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = pageBox();

        TextView title = heading("Keuangan Saya", 26);
        box.addView(title);
        box.addView(subtitle(currentMonthLabel()));

        MonthTotals mt = calculateMonthTotals(new Date());
        long allNet = calculateAllNet();
        long opening = prefs.getLong(KEY_OPENING, 0);
        long recordedBalance = opening + allNet;

        LinearLayout balance = card();
        TextView b1 = subtitle("Saldo Tercatat");
        TextView b2 = heading(money(recordedBalance), 29);
        balance.addView(b1);
        balance.addView(b2);
        box.addView(balance);

        LinearLayout pair = new LinearLayout(this);
        pair.setOrientation(LinearLayout.HORIZONTAL);
        pair.addView(summaryCard("Pemasukan", mt.income, GREEN_2),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        pair.addView(summaryCard("Pengeluaran", mt.expense, RED),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        box.addView(pair);

        long saving = mt.income - mt.expense;
        int savingRate = mt.income > 0 ? (int) Math.round((saving * 100.0) / mt.income) : 0;
        LinearLayout savingCard = card();
        savingCard.addView(subtitle("Sisa / Saving Bulan Ini"));
        TextView saveAmount = heading(money(saving), 23);
        saveAmount.setTextColor(saving >= 0 ? GREEN_2 : RED);
        savingCard.addView(saveAmount);
        savingCard.addView(subtitle(mt.income > 0 ? "Saving rate " + savingRate + "%" : "Belum ada pemasukan bulan ini"));
        box.addView(savingCard);

        Button add = primaryButton("+  TAMBAH TRANSAKSI");
        add.setOnClickListener(v -> showTab(2));
        box.addView(add);

        box.addView(sectionTitle("Pengeluaran Terbesar"));
        Map<String, Long> cat = categoryExpenseThisMonth();
        List<Map.Entry<String, Long>> entries = new ArrayList<>(cat.entrySet());
        entries.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
        if (entries.isEmpty()) {
            box.addView(emptyText("Belum ada pengeluaran bulan ini."));
        } else {
            int count = Math.min(5, entries.size());
            for (int i = 0; i < count; i++) {
                Map.Entry<String, Long> e = entries.get(i);
                box.addView(simpleRow(e.getKey(), money(e.getValue()), RED));
            }
        }

        box.addView(sectionTitle("Transaksi Terakhir"));
        JSONArray arr = loadTransactions();
        if (arr.length() == 0) {
            box.addView(emptyText("Belum ada transaksi."));
        } else {
            for (int i = arr.length() - 1, shown = 0; i >= 0 && shown < 5; i--, shown++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) box.addView(transactionCompact(o));
            }
        }

        scroll.addView(box);
        return scroll;
    }

    private View buildHistory() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = pageBox();
        box.addView(heading("Riwayat Transaksi", 25));
        box.addView(subtitle("Semua pemasukan dan pengeluaran yang sudah disimpan"));

        JSONArray arr = loadTransactions();
        if (arr.length() == 0) {
            box.addView(emptyText("Belum ada transaksi. Tekan menu Tambah untuk mulai."));
        } else {
            for (int i = arr.length() - 1; i >= 0; i--) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                final long id = o.optLong("id", 0);
                LinearLayout c = card();

                LinearLayout top = new LinearLayout(this);
                top.setOrientation(LinearLayout.HORIZONTAL);

                LinearLayout texts = new LinearLayout(this);
                texts.setOrientation(LinearLayout.VERTICAL);
                TextView merchant = heading(o.optString("merchant", "Transaksi"), 17);
                TextView meta = subtitle(formatDateDisplay(o.optString("date")) + " • "
                        + o.optString("category", "Lain-lain"));
                texts.addView(merchant);
                texts.addView(meta);

                TextView amount = new TextView(this);
                String type = o.optString("type", "Pengeluaran");
                String prefix = "Pemasukan".equals(type) ? "+ " : "Transfer Antar Akun".equals(type) ? "↔ " : "- ";
                amount.setText(prefix + money(o.optLong("amount")));
                amount.setTextSize(17);
                amount.setTypeface(null, Typeface.BOLD);
                amount.setTextColor("Pemasukan".equals(type) ? GREEN_2 : "Transfer Antar Akun".equals(type) ? ORANGE : RED);
                amount.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);

                top.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                top.addView(amount, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
                c.addView(top);

                String note = o.optString("note", "");
                String account = o.optString("account", "");
                if (!note.isEmpty()) c.addView(subtitle(note));
                if (!account.isEmpty()) c.addView(subtitle("Akun: " + account));

                Button del = secondaryButton("Hapus");
                del.setTextColor(RED);
                del.setOnClickListener(v -> confirmDelete(id));
                c.addView(del);
                box.addView(c);
            }
        }
        scroll.addView(box);
        return scroll;
    }

    private View buildAddMenu() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = pageBox();
        box.addView(heading("Tambah Transaksi", 25));
        box.addView(subtitle("Pilih cara input yang paling cepat"));

        LinearLayout manual = actionCard("⌨", "Input Manual",
                "Isi tanggal, jenis, nominal, kategori dan keterangan.");
        manual.setOnClickListener(v -> showEntryDialog(null, false));
        box.addView(manual);

        LinearLayout screenshot = actionCard("▣", "Baca Screenshot",
                "Pilih screenshot transaksi. Hasil OCR akan ditampilkan untuk dicek sebelum disimpan.");
        screenshot.setOnClickListener(v -> pickScreenshot());
        box.addView(screenshot);

        LinearLayout info = card();
        TextView t = subtitle("Agar pembacaan lebih akurat, aplikasi memprioritaskan angka yang berdekatan dengan kata Rp / Nominal / Total, dan mengabaikan angka rekening, nomor referensi, serta saldo.");
        info.addView(t);
        box.addView(info);

        scroll.addView(box);
        return scroll;
    }

    private View buildAnalysis() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = pageBox();
        box.addView(heading("Analisa Bulanan", 25));
        box.addView(subtitle(currentMonthLabel()));

        MonthTotals mt = calculateMonthTotals(new Date());
        box.addView(simpleRow("Total Pemasukan", money(mt.income), GREEN_2));
        box.addView(simpleRow("Total Pengeluaran", money(mt.expense), RED));
        box.addView(simpleRow("Sisa Bulan Ini", money(mt.income - mt.expense),
                mt.income - mt.expense >= 0 ? GREEN_2 : RED));

        box.addView(sectionTitle("Pengeluaran per Kategori"));
        Map<String, Long> data = categoryExpenseThisMonth();
        List<Map.Entry<String, Long>> entries = new ArrayList<>(data.entrySet());
        entries.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));

        if (entries.isEmpty()) {
            box.addView(emptyText("Belum ada data pengeluaran bulan ini."));
        } else {
            long max = entries.get(0).getValue();
            for (Map.Entry<String, Long> e : entries) {
                LinearLayout c = card();
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                TextView left = new TextView(this);
                left.setText(e.getKey());
                left.setTextColor(TEXT);
                left.setTextSize(15);
                TextView right = new TextView(this);
                right.setText(money(e.getValue()));
                right.setTextColor(RED);
                right.setTextSize(15);
                right.setTypeface(null, Typeface.BOLD);
                right.setGravity(Gravity.RIGHT);
                row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                row.addView(right, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                c.addView(row);

                ProgressBar p = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
                p.setMax(100);
                p.setProgress(max > 0 ? (int) Math.round(e.getValue() * 100.0 / max) : 0);
                c.addView(p, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(8)));
                box.addView(c);
            }
        }

        scroll.addView(box);
        return scroll;
    }

    private View buildSettings() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = pageBox();
        box.addView(heading("Setting", 25));
        box.addView(subtitle("Pengaturan dasar aplikasi"));

        LinearLayout opening = card();
        opening.addView(sectionTitle("Saldo Awal"));
        EditText saldo = input("Contoh: 5000000");
        saldo.setInputType(InputType.TYPE_CLASS_NUMBER);
        long existing = prefs.getLong(KEY_OPENING, 0);
        if (existing > 0) saldo.setText(String.valueOf(existing));
        opening.addView(saldo);
        Button save = primaryButton("Simpan Saldo Awal");
        save.setOnClickListener(v -> {
            long value = parseLongSafe(saldo.getText().toString());
            prefs.edit().putLong(KEY_OPENING, value).apply();
            Toast.makeText(this, "Saldo awal disimpan", Toast.LENGTH_SHORT).show();
            showTab(0);
        });
        opening.addView(save);
        box.addView(opening);

        LinearLayout about = card();
        about.addView(sectionTitle("Tentang Data"));
        about.addView(subtitle("Data transaksi disimpan lokal di HP. Screenshot hanya dibaca saat dipilih dan tidak otomatis disimpan sebagai transaksi sebelum Anda menekan tombol Simpan."));
        box.addView(about);

        Button reset = secondaryButton("Hapus Semua Data Transaksi");
        reset.setTextColor(RED);
        reset.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Hapus semua transaksi?")
                    .setMessage("Tindakan ini tidak dapat dibatalkan.")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus", (d, w) -> {
                        prefs.edit().putString(KEY_TX, "[]").apply();
                        Toast.makeText(this, "Data transaksi dihapus", Toast.LENGTH_SHORT).show();
                        showTab(0);
                    }).show();
        });
        box.addView(reset);

        scroll.addView(box);
        return scroll;
    }

    private void pickScreenshot() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        startActivityForResult(pick, REQ_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            readScreenshot(data.getData());
        }
    }

    private void readScreenshot(Uri uri) {
        final AlertDialog progress = new AlertDialog.Builder(this)
                .setTitle("Membaca screenshot")
                .setMessage("OCR sedang membaca teks transaksi...")
                .setCancelable(false)
                .create();
        progress.show();

        try {
            InputImage image = InputImage.fromFilePath(this, uri);
            TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            recognizer.process(image)
                    .addOnSuccessListener(text -> {
                        progress.dismiss();
                        ParsedTransaction parsed = parseOcr(text);
                        showOcrPreview(parsed);
                        recognizer.close();
                    })
                    .addOnFailureListener(e -> {
                        progress.dismiss();
                        recognizer.close();
                        Toast.makeText(this, "Screenshot gagal dibaca: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    });
        } catch (IOException e) {
            progress.dismiss();
            Toast.makeText(this, "Gambar tidak dapat dibuka.", Toast.LENGTH_LONG).show();
        }
    }

    private void showOcrPreview(ParsedTransaction p) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(18), dp(8), dp(18), dp(8));

        TextView status = new TextView(this);
        status.setText(p.amount > 0
                ? "Hasil pembacaan ditemukan. Cek dahulu sebelum disimpan."
                : "Nominal belum terbaca dengan yakin. Silakan koreksi manual.");
        status.setTextColor(p.amount > 0 ? GREEN_2 : ORANGE);
        status.setTextSize(14);
        status.setPadding(0, 0, 0, dp(10));
        wrap.addView(status);

        wrap.addView(previewLine("Tanggal", formatDateDisplay(p.date)));
        wrap.addView(previewLine("Jenis", p.type));
        wrap.addView(previewLine("Nominal", p.amount > 0 ? money(p.amount) : "Belum terbaca"));
        wrap.addView(previewLine("Merchant / Penerima", p.merchant));
        wrap.addView(previewLine("Kategori", p.category));
        wrap.addView(previewLine("Akun", p.account.isEmpty() ? "-" : p.account));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(wrap);

        new AlertDialog.Builder(this)
                .setTitle("Konfirmasi Screenshot")
                .setView(scroll)
                .setNegativeButton("Batal", null)
                .setNeutralButton("Lihat Teks OCR", (d, w) -> showRawOcr(p.rawText))
                .setPositiveButton("Cek & Edit", (d, w) -> showEntryDialog(p, true))
                .show();
    }

    private void showRawOcr(String raw) {
        TextView tv = new TextView(this);
        tv.setText(raw == null || raw.trim().isEmpty() ? "(Tidak ada teks terbaca)" : raw);
        tv.setTextSize(13);
        tv.setTextColor(TEXT);
        tv.setPadding(dp(18), dp(12), dp(18), dp(12));
        ScrollView s = new ScrollView(this);
        s.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle("Teks hasil OCR")
                .setView(s)
                .setPositiveButton("Tutup", null)
                .show();
    }

    private void showEntryDialog(ParsedTransaction p, boolean fromOcr) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(6), dp(18), dp(12));

        TextView warn = subtitle(fromOcr
                ? "Periksa hasil OCR. Transaksi belum disimpan sampai Anda menekan Simpan."
                : "Isi data transaksi.");
        warn.setTextColor(fromOcr ? ORANGE : MUTED);
        form.addView(warn);

        form.addView(fieldLabel("Jenis"));
        Spinner type = spinner(new String[]{"Pengeluaran", "Pemasukan", "Transfer Antar Akun"});
        if (p != null) selectSpinner(type, p.type);
        form.addView(type);

        form.addView(fieldLabel("Tanggal (yyyy-MM-dd)"));
        EditText date = input("2026-10-04");
        date.setText(p != null && p.date != null ? p.date : todayIso());
        form.addView(date);

        form.addView(fieldLabel("Nominal"));
        EditText amount = input("Contoh: 250000");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER);
        if (p != null && p.amount > 0) amount.setText(String.valueOf(p.amount));
        form.addView(amount);

        form.addView(fieldLabel("Kategori"));
        Spinner category = spinner(categories);
        if (p != null) selectSpinner(category, p.category);
        form.addView(category);

        form.addView(fieldLabel("Merchant / Penerima"));
        EditText merchant = input("Contoh: Shopee / Pertamina / Gaji");
        if (p != null) merchant.setText(p.merchant);
        form.addView(merchant);

        form.addView(fieldLabel("Akun / Rekening"));
        EditText account = input("Contoh: BCA, Mandiri, GoPay");
        if (p != null) account.setText(p.account);
        form.addView(account);

        form.addView(fieldLabel("Metode Pembayaran"));
        EditText method = input("Contoh: Transfer, QRIS, Debit");
        if (p != null) method.setText(p.method);
        form.addView(method);

        form.addView(fieldLabel("Keterangan"));
        EditText note = input("Opsional");
        if (p != null) note.setText(p.note);
        form.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(form);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(fromOcr ? "Cek & Edit Transaksi" : "Input Manual")
                .setView(scroll)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", null)
                .create();

        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            long nominal = parseLongSafe(amount.getText().toString());
            if (nominal <= 0) {
                amount.setError("Nominal wajib diisi");
                return;
            }
            if (!isValidIsoDate(date.getText().toString().trim())) {
                date.setError("Format tanggal harus yyyy-MM-dd");
                return;
            }

            JSONObject o = new JSONObject();
            try {
                o.put("id", System.currentTimeMillis());
                o.put("date", date.getText().toString().trim());
                o.put("type", type.getSelectedItem().toString());
                o.put("amount", nominal);
                o.put("category", category.getSelectedItem().toString());
                o.put("merchant", nonEmpty(merchant.getText().toString(), "Transaksi"));
                o.put("account", account.getText().toString().trim());
                o.put("method", method.getText().toString().trim());
                o.put("note", note.getText().toString().trim());
                o.put("source", fromOcr ? "Screenshot" : "Manual");
                o.put("ocrText", p != null ? p.rawText : "");
                addTransaction(o);
                dialog.dismiss();
                Toast.makeText(this, "Transaksi tersimpan", Toast.LENGTH_SHORT).show();
                showTab(0);
            } catch (Exception e) {
                Toast.makeText(this, "Gagal menyimpan transaksi", Toast.LENGTH_SHORT).show();
            }
        }));
        dialog.show();
    }

    private ParsedTransaction parseOcr(Text text) {
        ParsedTransaction p = new ParsedTransaction();
        p.date = todayIso();
        p.type = "Pengeluaran";
        p.category = "Lain-lain";
        p.merchant = "Transaksi Screenshot";
        p.note = "Dibaca dari screenshot";
        p.account = "";
        p.method = "";
        p.rawText = text == null ? "" : text.getText();

        if (text == null || p.rawText.trim().isEmpty()) return p;

        List<String> lines = new ArrayList<>();
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String s = line.getText() == null ? "" : line.getText().trim();
                if (!s.isEmpty()) lines.add(s);
            }
        }
        if (lines.isEmpty()) {
            Collections.addAll(lines, p.rawText.split("\\r?\\n"));
        }

        p.date = detectDate(lines);
        p.amount = detectAmount(lines);
        p.type = detectType(lines);
        p.account = detectAccount(lines);
        p.method = detectMethod(lines);
        p.merchant = detectMerchant(lines);
        p.category = detectCategory(lines, p.type, p.merchant);

        return p;
    }

    private long detectAmount(List<String> lines) {
        Pattern pat = Pattern.compile("(?i)(?:Rp\\s*)?([0-9]{1,3}(?:[\\.\\s][0-9]{3})+(?:,[0-9]{1,2})?|[0-9]{4,12})(?:,[0-9]{1,2})?");
        long bestAmount = 0;
        int bestScore = Integer.MIN_VALUE;

        for (int i = 0; i < lines.size(); i++) {
            String original = lines.get(i);
            String u = original.toUpperCase(Locale.ROOT);
            Matcher m = pat.matcher(original);
            while (m.find()) {
                String token = m.group(0);
                long amount = parseMoneyToken(token);
                if (amount <= 0 || amount > 5_000_000_000L) continue;

                int score = 0;
                if (u.contains("RP")) score += 9;
                if (containsAny(u, "NOMINAL", "TOTAL", "JUMLAH", "AMOUNT")) score += 7;
                if (containsAny(u, "TRANSFER", "PEMBAYARAN", "BAYAR", "QRIS", "DEBIT", "KREDIT", "TRANSAKSI")) score += 4;
                if (containsAny(u, "SALDO", "BALANCE")) score -= 10;
                if (containsAny(u, "REKENING", "NO. REK", "NO REK", "REFERENCE", "REFERENSI",
                        "NO. REF", "NO REF", "TRX ID", "ID TRANSAKSI", "ORDER ID", "VIRTUAL ACCOUNT", "VA ")) score -= 12;
                if (containsAny(u, "BIAYA ADMIN", "ADMIN")) score -= 3;
                if (token.toUpperCase(Locale.ROOT).startsWith("RP")) score += 4;
                if (amount >= 1000) score += 1;

                if (i > 0) {
                    String prev = lines.get(i - 1).toUpperCase(Locale.ROOT);
                    if (containsAny(prev, "NOMINAL", "TOTAL", "JUMLAH", "AMOUNT")) score += 5;
                    if (containsAny(prev, "SALDO", "REKENING", "REFERENSI")) score -= 5;
                }
                if (i + 1 < lines.size()) {
                    String next = lines.get(i + 1).toUpperCase(Locale.ROOT);
                    if (containsAny(next, "BERHASIL", "SUKSES")) score += 2;
                }

                if (score > bestScore || (score == bestScore && amount > bestAmount)) {
                    bestScore = score;
                    bestAmount = amount;
                }
            }
        }
        return bestAmount;
    }

    private String detectDate(List<String> lines) {
        String[] patterns = {
                "(\\d{1,2})[/-](\\d{1,2})[/-](20\\d{2})",
                "(20\\d{2})[/-](\\d{1,2})[/-](\\d{1,2})"
        };
        for (String line : lines) {
            for (int pi = 0; pi < patterns.length; pi++) {
                Matcher m = Pattern.compile(patterns[pi]).matcher(line);
                if (m.find()) {
                    try {
                        if (pi == 0) {
                            return String.format(Locale.US, "%04d-%02d-%02d",
                                    Integer.parseInt(m.group(3)),
                                    Integer.parseInt(m.group(2)),
                                    Integer.parseInt(m.group(1)));
                        } else {
                            return String.format(Locale.US, "%04d-%02d-%02d",
                                    Integer.parseInt(m.group(1)),
                                    Integer.parseInt(m.group(2)),
                                    Integer.parseInt(m.group(3)));
                        }
                    } catch (Exception ignored) {}
                }
            }
        }

        Pattern words = Pattern.compile("(?i)(\\d{1,2})\\s+(Jan(?:uari)?|Feb(?:ruari)?|Mar(?:et)?|Apr(?:il)?|Mei|Jun(?:i)?|Jul(?:i)?|Agu(?:stus)?|Sep(?:tember)?|Okt(?:ober)?|Nov(?:ember)?|Des(?:ember)?)\\s+(20\\d{2})");
        Map<String, Integer> months = new HashMap<>();
        months.put("JAN",1); months.put("JANUARI",1); months.put("FEB",2); months.put("FEBRUARI",2);
        months.put("MAR",3); months.put("MARET",3); months.put("APR",4); months.put("APRIL",4);
        months.put("MEI",5); months.put("JUN",6); months.put("JUNI",6); months.put("JUL",7); months.put("JULI",7);
        months.put("AGU",8); months.put("AGUSTUS",8); months.put("SEP",9); months.put("SEPTEMBER",9);
        months.put("OKT",10); months.put("OKTOBER",10); months.put("NOV",11); months.put("NOVEMBER",11);
        months.put("DES",12); months.put("DESEMBER",12);

        for (String line : lines) {
            Matcher m = words.matcher(line);
            if (m.find()) {
                String key = m.group(2).toUpperCase(Locale.ROOT);
                Integer month = months.get(key);
                if (month != null) {
                    return String.format(Locale.US, "%04d-%02d-%02d",
                            Integer.parseInt(m.group(3)), month, Integer.parseInt(m.group(1)));
                }
            }
        }
        return todayIso();
    }

    private String detectType(List<String> lines) {
        String all = joinUpper(lines);
        if (containsAny(all, "TRANSFER MASUK", "DANA MASUK", "UANG MASUK", "DITERIMA",
                "RECEIVED", "CREDITED", "KREDIT MASUK", "REFUND", "CASHBACK MASUK")) {
            return "Pemasukan";
        }
        if (containsAny(all, "TRANSFER DARI", "PENGIRIM", "FROM ")) {
            return "Pemasukan";
        }
        if (containsAny(all, "TRANSFER KE", "KIRIM KE", "PEMBAYARAN", "PAYMENT", "QRIS",
                "DEBIT", "PEMBELIAN", "BAYAR", "PENERIMA", "TUJUAN")) {
            return "Pengeluaran";
        }
        return "Pengeluaran";
    }

    private String detectAccount(List<String> lines) {
        String all = joinUpper(lines);
        if (all.contains("BCA")) return "BCA";
        if (all.contains("MANDIRI")) return "Mandiri";
        if (all.contains("CIMB")) return "CIMB Niaga";
        if (all.contains("BRI")) return "BRI";
        if (all.contains("BNI")) return "BNI";
        if (all.contains("SEABANK")) return "SeaBank";
        if (all.contains("BANK JAGO") || all.contains("JAGO")) return "Bank Jago";
        if (all.contains("PERMATA")) return "Permata";
        if (all.contains("GOPAY")) return "GoPay";
        if (all.contains("SHOPEEPAY")) return "ShopeePay";
        if (all.contains("OVO")) return "OVO";
        if (all.contains("DANA")) return "DANA";
        return "";
    }

    private String detectMethod(List<String> lines) {
        String all = joinUpper(lines);
        if (all.contains("QRIS")) return "QRIS";
        if (containsAny(all, "TRANSFER", "BI-FAST", "BI FAST")) return "Transfer";
        if (all.contains("DEBIT")) return "Debit";
        if (all.contains("KARTU KREDIT") || all.contains("CREDIT CARD")) return "Kartu Kredit";
        if (all.contains("TOP UP")) return "Top Up";
        return "";
    }

    private String detectMerchant(List<String> lines) {
        String[] keys = {"PENERIMA", "MERCHANT", "KEPADA", "TUJUAN", "TRANSFER KE", "KIRIM KE"};
        for (int i = 0; i < lines.size(); i++) {
            String u = lines.get(i).toUpperCase(Locale.ROOT);
            for (String key : keys) {
                int pos = u.indexOf(key);
                if (pos >= 0) {
                    String original = lines.get(i);
                    String value = original.substring(Math.min(original.length(), pos + key.length()))
                            .replaceFirst("^\\s*[:\\-]\\s*", "").trim();
                    if (isMerchantLike(value)) return cleanupMerchant(value);
                    if (i + 1 < lines.size() && isMerchantLike(lines.get(i + 1))) {
                        return cleanupMerchant(lines.get(i + 1));
                    }
                }
            }
        }

        String[] known = {"SHOPEE", "TOKOPEDIA", "PERTAMINA", "INDOMARET", "ALFAMART",
                "GRAB", "GOJEK", "STARBUCKS", "MCDONALD", "KFC", "PLN", "TELKOMSEL"};
        for (String line : lines) {
            String u = line.toUpperCase(Locale.ROOT);
            for (String k : known) {
                if (u.contains(k)) return cleanupMerchant(line);
            }
        }
        return "Transaksi Screenshot";
    }

    private String detectCategory(List<String> lines, String type, String merchant) {
        if ("Pemasukan".equals(type)) return "Pemasukan";
        String all = (joinUpper(lines) + " " + merchant.toUpperCase(Locale.ROOT));
        if (containsAny(all, "PERTAMINA", "SHELL", "BP AKR", "GRAB", "GOJEK", "PARKIR", "TOL")) return "Transportasi";
        if (containsAny(all, "INDOMARET", "ALFAMART", "SHOPEE", "TOKOPEDIA", "LAZADA", "BLIBLI")) return "Belanja";
        if (containsAny(all, "PLN", "PDAM", "TELKOM", "TELKOMSEL", "INDIHOME", "INTERNET", "LISTRIK", "PULSA")) return "Tagihan";
        if (containsAny(all, "STARBUCKS", "MCDONALD", "MCD ", "KFC", "RESTO", "RESTAURANT", "CAFE", "KOPI", "MAKAN", "FOOD")) return "Makan & Minum";
        if (containsAny(all, "KPR", "CICILAN", "ANGSURAN", "LOAN")) return "Cicilan";
        if (containsAny(all, "APOTEK", "HOSPITAL", "RUMAH SAKIT", "KLINIK", "DOKTER")) return "Kesehatan";
        if (containsAny(all, "REKSA DANA", "INVESTASI", "SAHAM", "DEPOSITO", "TABUNGAN")) return "Tabungan / Investasi";
        return "Lain-lain";
    }

    private void addTransaction(JSONObject o) {
        JSONArray arr = loadTransactions();
        arr.put(o);
        prefs.edit().putString(KEY_TX, arr.toString()).apply();
    }

    private void confirmDelete(long id) {
        new AlertDialog.Builder(this)
                .setTitle("Hapus transaksi?")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus", (d, w) -> {
                    JSONArray src = loadTransactions();
                    JSONArray dst = new JSONArray();
                    for (int i = 0; i < src.length(); i++) {
                        JSONObject o = src.optJSONObject(i);
                        if (o != null && o.optLong("id") != id) dst.put(o);
                    }
                    prefs.edit().putString(KEY_TX, dst.toString()).apply();
                    Toast.makeText(this, "Transaksi dihapus", Toast.LENGTH_SHORT).show();
                    showTab(1);
                }).show();
    }

    private JSONArray loadTransactions() {
        try {
            return new JSONArray(prefs.getString(KEY_TX, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private MonthTotals calculateMonthTotals(Date monthDate) {
        MonthTotals m = new MonthTotals();
        SimpleDateFormat ym = new SimpleDateFormat("yyyy-MM", Locale.US);
        String key = ym.format(monthDate);
        JSONArray arr = loadTransactions();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null || !o.optString("date").startsWith(key)) continue;
            String type = o.optString("type");
            long amount = o.optLong("amount");
            if ("Pemasukan".equals(type)) m.income += amount;
            else if ("Pengeluaran".equals(type)) m.expense += amount;
        }
        return m;
    }

    private long calculateAllNet() {
        long income = 0, expense = 0;
        JSONArray arr = loadTransactions();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            if ("Pemasukan".equals(o.optString("type"))) income += o.optLong("amount");
            if ("Pengeluaran".equals(o.optString("type"))) expense += o.optLong("amount");
        }
        return income - expense;
    }

    private Map<String, Long> categoryExpenseThisMonth() {
        Map<String, Long> out = new HashMap<>();
        String key = new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date());
        JSONArray arr = loadTransactions();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            if (!o.optString("date").startsWith(key)) continue;
            if (!"Pengeluaran".equals(o.optString("type"))) continue;
            String cat = o.optString("category", "Lain-lain");
            out.put(cat, out.getOrDefault(cat, 0L) + o.optLong("amount"));
        }
        return out;
    }

    private LinearLayout pageBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(18), dp(16), dp(24));
        return box;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), Color.rgb(232, 236, 239));
        c.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, dp(8));
        c.setLayoutParams(lp);
        return c;
    }

    private LinearLayout summaryCard(String label, long value, int color) {
        LinearLayout c = card();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(8), dp(3), dp(8));
        c.setLayoutParams(lp);
        c.addView(subtitle(label));
        TextView v = heading(money(value), 18);
        v.setTextColor(color);
        c.addView(v);
        return c;
    }

    private LinearLayout actionCard(String symbol, String title, String desc) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);

        TextView ic = new TextView(this);
        ic.setText(symbol);
        ic.setTextSize(28);
        ic.setTextColor(GREEN_2);
        ic.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        c.addView(ic, new LinearLayout.LayoutParams(dp(50), dp(55)));

        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.addView(heading(title, 18));
        txt.addView(subtitle(desc));
        c.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        return c;
    }

    private View simpleRow(String leftText, String rightText, int rightColor) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        TextView left = new TextView(this);
        left.setText(leftText);
        left.setTextColor(TEXT);
        left.setTextSize(15);
        TextView right = new TextView(this);
        right.setText(rightText);
        right.setTextColor(rightColor);
        right.setTypeface(null, Typeface.BOLD);
        right.setTextSize(15);
        right.setGravity(Gravity.RIGHT);
        c.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        c.addView(right, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return c;
    }

    private View transactionCompact(JSONObject o) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackgroundColor(Color.WHITE);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(heading(o.optString("merchant", "Transaksi"), 15));
        left.addView(subtitle(formatDateDisplay(o.optString("date")) + " • " + o.optString("category")));

        TextView amount = new TextView(this);
        String type = o.optString("type");
        String prefix = "Pemasukan".equals(type) ? "+ " : "Transfer Antar Akun".equals(type) ? "↔ " : "- ";
        amount.setText(prefix + money(o.optLong("amount")));
        amount.setTextSize(15);
        amount.setTypeface(null, Typeface.BOLD);
        amount.setTextColor("Pemasukan".equals(type) ? GREEN_2 : "Transfer Antar Akun".equals(type) ? ORANGE : RED);
        amount.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);

        row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(amount, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(2));
        row.setLayoutParams(lp);
        return row;
    }

    private TextView previewLine(String label, String value) {
        TextView tv = new TextView(this);
        tv.setText(label + "\n" + value);
        tv.setTextColor(TEXT);
        tv.setTextSize(15);
        tv.setPadding(0, dp(7), 0, dp(7));
        return tv;
    }

    private TextView heading(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(TEXT);
        t.setTextSize(size);
        t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView subtitle(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(MUTED);
        t.setTextSize(13);
        t.setPadding(0, dp(2), 0, dp(4));
        return t;
    }

    private TextView sectionTitle(String text) {
        TextView t = heading(text, 17);
        t.setPadding(0, dp(16), 0, dp(4));
        return t;
    }

    private TextView fieldLabel(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(TEXT);
        t.setTextSize(13);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, dp(10), 0, dp(4));
        return t;
    }

    private TextView emptyText(String text) {
        TextView t = subtitle(text);
        t.setPadding(dp(4), dp(12), dp(4), dp(12));
        return t;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(15);
        e.setTextColor(TEXT);
        e.setHintTextColor(Color.rgb(160, 165, 170));
        e.setSingleLine(true);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(215, 220, 224));
        e.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        e.setLayoutParams(lp);
        return e;
    }

    private Spinner spinner(String[] values) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_dropdown_item, values);
        s.setAdapter(a);
        s.setBackgroundColor(Color.WHITE);
        return s;
    }

    private void selectSpinner(Spinner s, String value) {
        if (value == null) return;
        for (int i = 0; i < s.getCount(); i++) {
            if (value.equalsIgnoreCase(String.valueOf(s.getItemAtPosition(i)))) {
                s.setSelection(i);
                return;
            }
        }
    }

    private Button primaryButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setTypeface(null, Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(GREEN_2);
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        lp.setMargins(0, dp(10), 0, dp(6));
        b.setLayoutParams(lp);
        return b;
    }

    private Button secondaryButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(GREEN_2);
        b.setTextSize(14);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(215, 220, 224));
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        lp.setMargins(0, dp(8), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private String money(long value) {
        DecimalFormatSymbols sym = new DecimalFormatSymbols(new Locale("id", "ID"));
        sym.setGroupingSeparator('.');
        DecimalFormat df = new DecimalFormat("#,###", sym);
        return "Rp " + df.format(value);
    }

    private long parseMoneyToken(String token) {
        if (token == null) return 0;
        String s = token.toUpperCase(Locale.ROOT)
                .replace("RP", "")
                .replace(" ", "")
                .trim();
        int comma = s.indexOf(',');
        if (comma >= 0) s = s.substring(0, comma);
        s = s.replace(".", "");
        s = s.replaceAll("[^0-9]", "");
        return parseLongSafe(s);
    }

    private long parseLongSafe(String s) {
        try {
            String cleaned = s == null ? "" : s.replaceAll("[^0-9]", "");
            if (cleaned.isEmpty()) return 0;
            return Long.parseLong(cleaned);
        } catch (Exception e) {
            return 0;
        }
    }

    private boolean containsAny(String text, String... keys) {
        for (String k : keys) if (text.contains(k)) return true;
        return false;
    }

    private String joinUpper(List<String> lines) {
        StringBuilder sb = new StringBuilder();
        for (String s : lines) sb.append(s.toUpperCase(Locale.ROOT)).append('\n');
        return sb.toString();
    }

    private boolean isMerchantLike(String s) {
        if (s == null) return false;
        String v = s.trim();
        if (v.length() < 2 || v.length() > 60) return false;
        if (v.matches("[0-9.\\- /]+")) return false;
        String u = v.toUpperCase(Locale.ROOT);
        return !containsAny(u, "RP ", "BERHASIL", "SUKSES", "TANGGAL", "WAKTU", "REKENING");
    }

    private String cleanupMerchant(String s) {
        if (s == null) return "Transaksi Screenshot";
        String v = s.replaceAll("\\s+", " ").trim();
        if (v.length() > 50) v = v.substring(0, 50).trim();
        return v.isEmpty() ? "Transaksi Screenshot" : v;
    }

    private String nonEmpty(String s, String fallback) {
        return s == null || s.trim().isEmpty() ? fallback : s.trim();
    }

    private String todayIso() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    private String currentMonthLabel() {
        return new SimpleDateFormat("MMMM yyyy", new Locale("id", "ID")).format(new Date());
    }

    private String formatDateDisplay(String iso) {
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(iso);
            return new SimpleDateFormat("dd MMM yyyy", new Locale("id", "ID")).format(d);
        } catch (Exception e) {
            return iso == null ? "-" : iso;
        }
    }

    private boolean isValidIsoDate(String s) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            f.setLenient(false);
            f.parse(s);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static class MonthTotals {
        long income = 0;
        long expense = 0;
    }

    private static class ParsedTransaction {
        String date;
        String type;
        long amount;
        String category;
        String merchant;
        String account;
        String method;
        String note;
        String rawText;
    }
}
