package com.banu.pengeluaran;

import android.app.AlertDialog;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends AppCompatActivity {
    LinearLayout listContainer; TextView txtStatus, txtMonthTotal; JSONArray records;
    final String PREFS="expense_prefs", KEY="records"; ActivityResultLauncher<String> pickImage;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        listContainer=findViewById(R.id.listContainer); txtStatus=findViewById(R.id.txtStatus); txtMonthTotal=findViewById(R.id.txtMonthTotal);
        loadRecords();
        pickImage=registerForActivityResult(new ActivityResultContracts.GetContent(), uri->{ if(uri!=null) processImage(uri); });
        findViewById(R.id.btnPick).setOnClickListener(v->pickImage.launch("image/*"));
        handleIntent(getIntent()); render();
    }
    @Override protected void onNewIntent(Intent i){ super.onNewIntent(i); setIntent(i); handleIntent(i); }
    void handleIntent(Intent i){
        if(Intent.ACTION_SEND.equals(i.getAction()) && i.getType()!=null && i.getType().startsWith("image/")){
            Uri u=i.getParcelableExtra(Intent.EXTRA_STREAM); if(u!=null) processImage(u);
        }
    }
    void processImage(Uri uri){
        txtStatus.setText("Membaca screenshot...");
        try{
            InputImage image=InputImage.fromFilePath(this,uri);
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                .addOnSuccessListener(r->{ String t=r.getText(); Draft d=parse(t); txtStatus.setText("Screenshot berhasil dibaca."); showConfirm(d); })
                .addOnFailureListener(e->txtStatus.setText("Gagal membaca screenshot."));
        }catch(Exception e){ txtStatus.setText("Gagal membuka screenshot."); }
    }
    Draft parse(String t){ Draft d=new Draft(); d.date=parseDate(t); d.amount=parseAmount(t); d.merchant=parseMerchant(t); d.category=categorize(t+" "+d.merchant); return d; }
    long parseAmount(String text){
        String[] lines=text.split("\\n"); ArrayList<Long> pri=new ArrayList<>(), all=new ArrayList<>();
        Pattern p=Pattern.compile("(?i)(?:rp\\.?\\s*)?(\\d{1,3}(?:[.,]\\d{3})+|\\d{4,10})");
        for(String line:lines){ Matcher m=p.matcher(line); while(m.find()){ try{
            long v=Long.parseLong(m.group(1).replaceAll("[^0-9]","")); if(v>=1000&&v<=1000000000L){ all.add(v);
            if(line.toLowerCase().matches(".*(grand total|total bayar|total|jumlah|nominal|amount|payment|bayar).*")) pri.add(v); }
        }catch(Exception ignored){} } }
        return !pri.isEmpty()?Collections.max(pri):(all.isEmpty()?0:Collections.max(all));
    }
    String parseDate(String text){
        Matcher m=Pattern.compile("\\b([0-3]?\\d)[/\\-.]([01]?\\d)[/\\-.](20\\d{2}|\\d{2})\\b").matcher(text);
        if(m.find()){ int y=Integer.parseInt(m.group(3)); if(y<100)y+=2000; return String.format(Locale.US,"%04d-%02d-%02d",y,Integer.parseInt(m.group(2)),Integer.parseInt(m.group(1))); }
        return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
    }
    String parseMerchant(String text){
        Pattern reject=Pattern.compile("(?i)(total|tanggal|date|time|transaction|transaksi|reference|saldo|balance|receipt|struk|terima kasih|thank|amount|nominal|rp\\s?\\d)");
        for(String l:text.split("\\n")){ String s=l.trim(); if(s.length()>=3&&s.length()<=60&&s.matches(".*[A-Za-z]{3}.*")&&!reject.matcher(s).find()) return s; }
        return "Pengeluaran";
    }
    String categorize(String s){
        s=s.toLowerCase();
        if(s.matches(".*(grab|gojek|gocar|goride|taxi|parkir|tol|pertamina|shell|spbu).*")) return "Transportasi";
        if(s.matches(".*(indomaret|alfamart|alfamidi|supermarket|hypermart|transmart).*")) return "Belanja Harian";
        if(s.matches(".*(restaurant|resto|coffee|kopi|cafe|kafe|bakso|mie|ayam|pizza|burger|food|makan|minum|starbucks|mcd|kfc|hokben).*")) return "Makanan & Minuman";
        if(s.matches(".*(pln|listrik|pdam|indihome|pulsa|token|bpjs|tagihan|internet|wifi).*")) return "Tagihan";
        if(s.matches(".*(apotek|hospital|rumah sakit|klinik|dokter|medical).*")) return "Kesehatan";
        if(s.matches(".*(cinema|bioskop|netflix|spotify|game|steam).*")) return "Hiburan";
        if(s.matches(".*(transfer|trf|send money).*")) return "Transfer";
        return "Lainnya";
    }
    void showConfirm(Draft d){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); int pad=(int)(16*getResources().getDisplayMetrics().density); box.setPadding(pad,pad,pad,pad);
        EditText merchant=new EditText(this); merchant.setHint("Merchant"); merchant.setText(d.merchant); box.addView(merchant);
        EditText amount=new EditText(this); amount.setHint("Nominal"); amount.setInputType(2); amount.setText(String.valueOf(d.amount)); box.addView(amount);
        EditText date=new EditText(this); date.setHint("Tanggal YYYY-MM-DD"); date.setText(d.date); box.addView(date);
        String[] cats={"Makanan & Minuman","Belanja Harian","Transportasi","Tagihan","Kesehatan","Hiburan","Transfer","Lainnya"};
        Spinner cat=new Spinner(this); cat.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats)); int idx=Arrays.asList(cats).indexOf(d.category); if(idx>=0)cat.setSelection(idx); box.addView(cat);
        new AlertDialog.Builder(this).setTitle("Cek Hasil Otomatis").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan",(x,w)->{
            try{ JSONObject o=new JSONObject(); o.put("id",System.currentTimeMillis()); o.put("date",date.getText().toString()); o.put("merchant",merchant.getText().toString());
                o.put("amount",Long.parseLong(amount.getText().toString().replaceAll("[^0-9]",""))); o.put("category",cat.getSelectedItem().toString()); records.put(o); persist(); render();
            }catch(Exception ignored){}
        }).show();
    }
    void loadRecords(){ try{ records=new JSONArray(getSharedPreferences(PREFS,MODE_PRIVATE).getString(KEY,"[]")); }catch(Exception e){ records=new JSONArray(); } }
    void persist(){ getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY,records.toString()).apply(); }
    String rp(long n){ return "Rp"+NumberFormat.getNumberInstance(new Locale("id","ID")).format(n); }
    void render(){
        listContainer.removeAllViews(); String ym=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date()); long month=0;
        for(int i=records.length()-1;i>=0;i--){ try{ JSONObject o=records.getJSONObject(i); if(o.optString("date").startsWith(ym))month+=o.optLong("amount");
            if(records.length()-1-i<30){ TextView tv=new TextView(this); tv.setText(o.optString("merchant")+"\\n"+o.optString("date")+" · "+o.optString("category")+"\\n"+rp(o.optLong("amount"))); tv.setTextSize(16); tv.setPadding(0,18,0,18); listContainer.addView(tv); }
        }catch(Exception ignored){} } txtMonthTotal.setText(rp(month));
    }
    static class Draft { String date,merchant,category; long amount; }
}
