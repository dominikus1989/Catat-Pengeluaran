package com.banu.pengeluaran;

import android.app.AlertDialog;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends AppCompatActivity {
    LinearLayout listContainer;
    TextView txtStatus, txtMonthTotal;
    JSONArray records;
    final String PREFS="expense_prefs", KEY="records";
    ActivityResultLauncher<String> pickImage;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        listContainer=findViewById(R.id.listContainer);
        txtStatus=findViewById(R.id.txtStatus);
        txtMonthTotal=findViewById(R.id.txtMonthTotal);

        loadRecords();

        pickImage=registerForActivityResult(new ActivityResultContracts.GetContent(), uri->{
            if(uri!=null) processImage(uri);
        });

        findViewById(R.id.btnPick).setOnClickListener(v->pickImage.launch("image/*"));

        findViewById(R.id.btnClear).setOnClickListener(v->
            new AlertDialog.Builder(this)
                .setTitle("Hapus semua transaksi?")
                .setMessage("Semua catatan pengeluaran di aplikasi akan dihapus.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus", (d,w)->{
                    records=new JSONArray();
                    persist();
                    render();
                }).show()
        );

        handleIntent(getIntent());
        render();
    }

    @Override protected void onNewIntent(Intent i){
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    void handleIntent(Intent i){
        if(Intent.ACTION_SEND.equals(i.getAction()) && i.getType()!=null && i.getType().startsWith("image/")){
            Uri u=i.getParcelableExtra(Intent.EXTRA_STREAM);
            if(u!=null) processImage(u);
        }
    }

    void processImage(Uri uri){
        txtStatus.setText("Membaca screenshot...");
        try{
            InputImage image=InputImage.fromFilePath(this,uri);
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(image)
                .addOnSuccessListener(r->{
                    String t=r.getText();
                    Draft d=parse(t);
                    txtStatus.setText("Screenshot berhasil dibaca.");
                    showConfirm(d, t);
                })
                .addOnFailureListener(e->txtStatus.setText("Gagal membaca screenshot."));
        }catch(Exception e){
            txtStatus.setText("Gagal membuka screenshot.");
        }
    }

    Draft parse(String t){
        Draft d=new Draft();
        d.date=parseDate(t);
        d.amount=parseAmount(t);
        d.merchant=parseMerchant(t);
        d.category=categorize(t+" "+d.merchant);
        return d;
    }

    long parseAmount(String text){
        String[] lines=text.split("\\n");

        // 1) Prioritas tertinggi: TOTAL BELANJA / GRAND TOTAL / TOTAL BAYAR / JUMLAH BAYAR
        Pattern amountPattern=Pattern.compile("(?i)(?:rp\\.?\\s*)?(\\d{1,3}(?:[.,]\\d{3})+|\\d{4,9})");

        String[] strongKeys={
            "total belanja","grand total","total bayar","jumlah bayar",
            "total payment","total amount","amount paid"
        };

        for(String key: strongKeys){
            for(String line: lines){
                String low=line.toLowerCase();
                if(low.contains(key)){
                    Matcher m=amountPattern.matcher(line);
                    ArrayList<Long> vals=new ArrayList<>();
                    while(m.find()){
                        long v=cleanAmount(m.group(1));
                        if(v>=1000 && v<=100000000) vals.add(v);
                    }
                    if(!vals.isEmpty()) return Collections.max(vals);
                }
            }
        }

        // 2) Prioritas kedua: TOTAL (tetapi bukan subtotal/diskon/dpp/ppn)
        for(String line: lines){
            String low=line.toLowerCase();
            if(low.contains("total")
                    && !low.contains("subtotal")
                    && !low.contains("diskon")
                    && !low.contains("dpp")
                    && !low.contains("ppn")
                    && !low.contains("hemat")){
                Matcher m=amountPattern.matcher(line);
                ArrayList<Long> vals=new ArrayList<>();
                while(m.find()){
                    long v=cleanAmount(m.group(1));
                    if(v>=1000 && v<=100000000) vals.add(v);
                }
                if(!vals.isEmpty()) return Collections.max(vals);
            }
        }

        // 3) Fallback: abaikan baris yang jelas bukan nominal transaksi
        ArrayList<Long> candidates=new ArrayList<>();
        Pattern reject=Pattern.compile("(?i)(telp|telepon|phone|wa |whatsapp|npwp|trxid|trx id|id poin|order|kode|receipt|ref|reference|tanggal|date|time|alamat|jl |jalan|purchase:|no:|kasir)");
        for(String line: lines){
            if(reject.matcher(line).find()) continue;
            Matcher m=amountPattern.matcher(line);
            while(m.find()){
                long v=cleanAmount(m.group(1));
                if(v>=1000 && v<=1000000) candidates.add(v);
            }
        }

        return candidates.isEmpty()?0:Collections.max(candidates);
    }

    long cleanAmount(String raw){
        try{
            return Long.parseLong(raw.replaceAll("[^0-9]",""));
        }catch(Exception e){
            return 0;
        }
    }

    String parseDate(String text){
        // menangkap contoh: 28.09.26-06:49, 29.09.26, 04/10/2026
        Matcher m=Pattern.compile("\\b([0-3]?\\d)[/\\-.]([01]?\\d)[/\\-.](20\\d{2}|\\d{2})\\b").matcher(text);
        if(m.find()){
            int y=Integer.parseInt(m.group(3));
            if(y<100) y+=2000;
            return String.format(Locale.US,"%04d-%02d-%02d", y,
                    Integer.parseInt(m.group(2)), Integer.parseInt(m.group(1)));
        }
        return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
    }

    String parseMerchant(String text){
        String[] lines=text.split("\\n");

        // Pilih nama cabang/toko, bukan nama legal perusahaan
        for(String l: lines){
            String s=l.trim();
            String low=s.toLowerCase();
            if(s.length()<3 || s.length()>70) continue;

            if((low.contains("indomaret") || low.contains("alfamart") || low.contains("alfamidi")
                    || low.contains("supermarket") || low.contains("hypermart"))
                    && !low.contains("pt.")
                    && !low.contains("indomarco prismatama")
                    && !low.contains("layanan konsumen")
                    && !low.contains("belanja lebih mudah")){
                return s;
            }
        }

        Pattern reject=Pattern.compile("(?i)(total|tanggal|date|time|transaction|transaksi|reference|saldo|balance|receipt|struk|terima kasih|thank|amount|nominal|rp\\s?\\d|npwp|telp|telepon|wa )");
        for(String l:lines){
            String s=l.trim();
            if(s.length()>=3 && s.length()<=60 && s.matches(".*[A-Za-z]{3}.*")
                    && !reject.matcher(s).find()
                    && !s.toLowerCase().contains("pt.indomarco prismatama")
                    && !s.toLowerCase().contains("pt. indomarco prismatama")){
                return s;
            }
        }
        return "Pengeluaran";
    }

    String categorize(String s){
        s=s.toLowerCase();

        if(s.matches(".*(point coffee|coffee|kopi|cafe|kafe|restaurant|resto|bakso|mie|ayam|pizza|burger|food|makan|minum|starbucks|mcd|kfc|hokben).*"))
            return "Makanan & Minuman";

        if(s.matches(".*(grab|gojek|gocar|goride|taxi|parkir|parking|tol|pertamina|shell|spbu).*"))
            return "Transportasi";

        if(s.matches(".*(indomaret|alfamart|alfamidi|supermarket|hypermart|transmart|lottemart).*"))
            return "Belanja Harian";

        if(s.matches(".*(pln|listrik|pdam|indihome|pulsa|token|bpjs|tagihan|internet|wifi).*"))
            return "Tagihan";

        if(s.matches(".*(apotek|pharmacy|hospital|rumah sakit|klinik|dokter|medical).*"))
            return "Kesehatan";

        if(s.matches(".*(cinema|bioskop|netflix|spotify|game|steam).*"))
            return "Hiburan";

        if(s.matches(".*(transfer|trf|send money).*"))
            return "Transfer";

        return "Lainnya";
    }

    boolean isDuplicate(String date, String merchant, long amount){
        String norm=normalizeMerchant(merchant);
        for(int i=0;i<records.length();i++){
            try{
                JSONObject o=records.getJSONObject(i);
                if(date.equals(o.optString("date"))
                        && amount==o.optLong("amount")
                        && norm.equals(normalizeMerchant(o.optString("merchant")))){
                    return true;
                }
            }catch(Exception ignored){}
        }
        return false;
    }

    String normalizeMerchant(String s){
        return s==null?"":s.toLowerCase().replaceAll("[^a-z0-9]","");
    }

    void showConfirm(Draft d, String rawText){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad=(int)(16*getResources().getDisplayMetrics().density);
        box.setPadding(pad,pad,pad,pad);

        EditText merchant=new EditText(this);
        merchant.setHint("Merchant");
        merchant.setText(d.merchant);
        box.addView(merchant);

        EditText amount=new EditText(this);
        amount.setHint("Nominal");
        amount.setInputType(2);
        amount.setText(d.amount==0?"":String.valueOf(d.amount));
        box.addView(amount);

        EditText date=new EditText(this);
        date.setHint("Tanggal YYYY-MM-DD");
        date.setText(d.date);
        box.addView(date);

        String[] cats={"Makanan & Minuman","Belanja Harian","Transportasi","Tagihan","Kesehatan","Hiburan","Transfer","Lainnya"};
        Spinner cat=new Spinner(this);
        cat.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats));
        int idx=Arrays.asList(cats).indexOf(d.category);
        if(idx>=0)cat.setSelection(idx);
        box.addView(cat);

        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle("Cek Hasil Otomatis")
            .setMessage("Pastikan nominal sesuai baris TOTAL BELANJA pada struk.")
            .setView(box)
            .setNegativeButton("Batal",null)
            .setPositiveButton("Simpan",null)
            .create();

        dialog.setOnShowListener(x->{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                try{
                    long a=Long.parseLong(amount.getText().toString().replaceAll("[^0-9]",""));
                    String dt=date.getText().toString();
                    String mc=merchant.getText().toString();

                    if(a<=0){
                        amount.setError("Nominal belum terbaca");
                        return;
                    }

                    Runnable saver=()->{
                        try{
                            JSONObject o=new JSONObject();
                            o.put("id",System.currentTimeMillis());
                            o.put("date",dt);
                            o.put("merchant",mc);
                            o.put("amount",a);
                            o.put("category",cat.getSelectedItem().toString());
                            records.put(o);
                            persist();
                            render();
                            dialog.dismiss();
                        }catch(Exception ignored){}
                    };

                    if(isDuplicate(dt,mc,a)){
                        new AlertDialog.Builder(this)
                            .setTitle("Kemungkinan duplikat")
                            .setMessage("Transaksi dengan tanggal, merchant, dan nominal yang sama sudah ada.")
                            .setNegativeButton("Batal",null)
                            .setPositiveButton("Tetap simpan",(dd,ww)->saver.run())
                            .show();
                    }else saver.run();

                }catch(Exception e){
                    amount.setError("Nominal tidak valid");
                }
            });
        });

        dialog.show();
    }

    void showEditDialog(int index){
        try{
            JSONObject o=records.getJSONObject(index);

            LinearLayout box=new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            int pad=(int)(16*getResources().getDisplayMetrics().density);
            box.setPadding(pad,pad,pad,pad);

            EditText merchant=new EditText(this);
            merchant.setText(o.optString("merchant"));
            box.addView(merchant);

            EditText amount=new EditText(this);
            amount.setInputType(2);
            amount.setText(String.valueOf(o.optLong("amount")));
            box.addView(amount);

            EditText date=new EditText(this);
            date.setText(o.optString("date"));
            box.addView(date);

            String[] cats={"Makanan & Minuman","Belanja Harian","Transportasi","Tagihan","Kesehatan","Hiburan","Transfer","Lainnya"};
            Spinner cat=new Spinner(this);
            cat.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats));
            int idx=Arrays.asList(cats).indexOf(o.optString("category"));
            if(idx>=0)cat.setSelection(idx);
            box.addView(cat);

            new AlertDialog.Builder(this)
                .setTitle("Edit Transaksi")
                .setView(box)
                .setNeutralButton("Hapus",(d,w)->{
                    removeAt(index);
                    persist();
                    render();
                })
                .setNegativeButton("Batal",null)
                .setPositiveButton("Simpan",(d,w)->{
                    try{
                        o.put("merchant",merchant.getText().toString());
                        o.put("amount",Long.parseLong(amount.getText().toString().replaceAll("[^0-9]","")));
                        o.put("date",date.getText().toString());
                        o.put("category",cat.getSelectedItem().toString());
                        persist();
                        render();
                    }catch(Exception ignored){}
                }).show();
        }catch(Exception ignored){}
    }

    void removeAt(int index){
        JSONArray n=new JSONArray();
        for(int i=0;i<records.length();i++){
            if(i==index) continue;
            try{ n.put(records.getJSONObject(i)); }catch(Exception ignored){}
        }
        records=n;
    }

    void loadRecords(){
        try{
            records=new JSONArray(getSharedPreferences(PREFS,MODE_PRIVATE).getString(KEY,"[]"));
        }catch(Exception e){
            records=new JSONArray();
        }
    }

    void persist(){
        getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY,records.toString()).apply();
    }

    String rp(long n){
        return "Rp"+NumberFormat.getNumberInstance(new Locale("id","ID")).format(n);
    }

    void render(){
        listContainer.removeAllViews();
        String ym=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());
        long month=0;

        for(int i=records.length()-1;i>=0;i--){
            try{
                JSONObject o=records.getJSONObject(i);
                if(o.optString("date").startsWith(ym)) month+=o.optLong("amount");

                if(records.length()-1-i<50){
                    TextView tv=new TextView(this);
                    tv.setText(
                        o.optString("merchant")+"\n"+
                        o.optString("date")+" · "+o.optString("category")+"\n"+
                        rp(o.optLong("amount"))
                    );
                    tv.setTextSize(16);
                    tv.setPadding(0,18,0,18);
                    tv.setClickable(true);
                    final int idx=i;
                    tv.setOnClickListener(v->showEditDialog(idx));
                    listContainer.addView(tv);
                }
            }catch(Exception ignored){}
        }
        txtMonthTotal.setText(rp(month));
    }

    static class Draft {
        String date,merchant,category;
        long amount;
    }
}
