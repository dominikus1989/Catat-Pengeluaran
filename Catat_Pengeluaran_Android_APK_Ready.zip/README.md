# Catat Pengeluaran Android v1.1

Perbaikan:
- Prioritas nominal dari TOTAL BELANJA / GRAND TOTAL / TOTAL BAYAR
- Abaikan nomor telepon, NPWP, TRX ID, nomor order
- Merchant memilih nama toko/cabang
- Deteksi duplikat transaksi
- Transaksi bisa diedit / dihapus
- Perbaikan tampilan newline
