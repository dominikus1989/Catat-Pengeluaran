# Catat Keuangan v2

Aplikasi Android sederhana untuk monitoring pemasukan dan pengeluaran harian.

## Fitur
- Dashboard pemasukan, pengeluaran, saldo tercatat, dan saving rate.
- Input transaksi manual.
- Upload / share screenshot transaksi dari HP.
- OCR ML Kit membaca teks screenshot.
- Parser nominal memprioritaskan Rp/Nominal/Total dan mengurangi skor angka yang terdeteksi sebagai saldo, rekening, nomor referensi, VA, atau ID transaksi.
- Deteksi tanggal, jenis transaksi, rekening/e-wallet, metode bayar, merchant/penerima, dan kategori.
- Hasil OCR wajib dikonfirmasi / diedit sebelum disimpan.
- Riwayat transaksi dan hapus transaksi.
- Analisa pengeluaran per kategori.
- Saldo awal di menu Setting.
- Data disimpan lokal di HP dengan SharedPreferences.

## Build
Project dirancang untuk workflow GitHub yang memakai:
- Java 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- compileSdk 35
- minSdk 23
- ML Kit Text Recognition 16.0.1

Perintah build:
`gradle assembleDebug`

APK debug:
`app/build/outputs/apk/debug/app-debug.apk`
