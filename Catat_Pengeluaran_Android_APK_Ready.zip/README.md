# Catat Pengeluaran Android

Aplikasi Android native untuk mencatat pengeluaran dari screenshot.

Fitur:
- Share screenshot dari Galeri langsung ke aplikasi
- OCR lokal dengan Google ML Kit
- Deteksi nominal, tanggal, merchant, kategori
- Konfirmasi sebelum simpan
- Total pengeluaran bulan berjalan
- Data tersimpan lokal di HP

Build APK otomatis:
1. Upload isi ZIP ini ke repository GitHub.
2. Buka Actions > Build Android APK.
3. Download artifact Catat-Pengeluaran-APK.
4. Extract lalu install Catat-Pengeluaran.apk.
